export class Project {
    id: number;
    name: String;
    description: String;
    startDate: Date;
    endDate: Date;
    businessUnit: String;
}
