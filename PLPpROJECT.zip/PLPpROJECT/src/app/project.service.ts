import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

import { HttpClient } from '@angular/common/http';
import { Project } from './project';


@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  baseUrl = 'http://localhost:8081/project';
  project: Project;
  id: number;
  constructor(private http: HttpClient) { }

  getUpdateData(project: Project): Project{
    this.id = project.id;
    this.project= project;
    return this.project;
  }
 
  addProduct(project: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/`, project);
  }

  displayAllProject(): Observable<any> {
    return this.http.get(`${this.baseUrl}/`);
  }

  deleteProject(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`, { responseType: 'text' });
  }

  updateProject() {
    return this.http.put(`${this.baseUrl}/${this.id}`, this.project);
  }

  searchProject(id :number){
    return this.http.get(`${this.baseUrl}/${id}`);
  }
}
