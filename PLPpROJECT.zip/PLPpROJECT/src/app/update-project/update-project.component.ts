import { Component, OnInit } from '@angular/core';
import { Project } from '../project';
import { ProjectService } from '../project.service';


@Component({
  selector: 'app-update-project',
  templateUrl: './update-project.component.html',
  styleUrls: ['./update-project.component.css']
})
export class UpdateProjectComponent implements OnInit {

  id: number;
  project: Project; // = { id: null, name: null, description: null, startDate: null, endDate: null, businessUnit: null };

  constructor(private projectService: ProjectService) { }

  ngOnInit() {
    
  }

  update() {
    this.projectService.searchProject(this.id).subscribe((data: Project) => { this.project = data; }, error => alert("no record found"));
    console.log(this.project);
  }

  updateProj()
  {
    this.project= this.projectService.getUpdateData(this.project);
    this.projectService.updateProject().subscribe((data: Project) => { this.project = data; });
  }

}
