import { Component, OnInit } from '@angular/core';
import { Project } from '../project';
import { ProjectService } from '../project.service';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit {

  project: Project = new Project();
  submitted = false;
  constructor(private projectService: ProjectService) { }

  ngOnInit() {
  }
  newProject(): void {
    this.submitted = false;
    this.project = new Project();
  }
  save() {
    this.projectService.addProduct(this.project).subscribe(data => console.log(data), error => console.log(error));
    this.project=new Project();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }

}
