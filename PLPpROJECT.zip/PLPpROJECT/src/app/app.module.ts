import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GetAllProjectsComponent } from './get-all-projects/get-all-projects.component';
import { HttpClientModule } from '@angular/common/http';
import { AddProjectComponent } from './add-project/add-project.component';
import { UpdateProjectComponent } from './update-project/update-project.component';
import { SearchProjectComponent } from './search-project/search-project.component';
@NgModule({
  declarations: [
    AppComponent,
    GetAllProjectsComponent,
    AddProjectComponent,
    UpdateProjectComponent,
    SearchProjectComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
